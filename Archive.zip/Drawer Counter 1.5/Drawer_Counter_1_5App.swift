//
//  Drawer_Counter_1_5App.swift
//  Drawer Counter 1.5
//
//  Created by Cason Voss on 3/23/23.
//

import SwiftUI

@main
struct Drawer_Counter_1_5App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
